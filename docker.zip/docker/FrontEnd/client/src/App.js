import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import P5Wrapper from 'react-p5-wrapper';
import Button from '@material-ui/core/Button';
import AppBar from '@material-ui/core/AppBar';

import DataWindow from "./Sketch/DataWindow"


class App extends Component {
  constructor(props) {
    super(props);
    this.state = {apiResponse: "", NodeServerStatus: false,color :undefined};
    this.movment = {}
    this.randomColor = this.randomColor.bind(this);
  }

  randomColor(){
    this.setState({color:[Math.random()*255, Math.random()*255, Math.random()*255]}
    )
  }

  /*
  sketch(p) {
    let x = 0
    let y = 0
    
    p.testFunction = () => {
      p.circle(x, y, 100);
    }

    p.setup = () => {
      p.createCanvas(window.innerWidth, window.innerHeight);
      x = 0
      y = 0
    };

    p.draw = () => {
      p.background(255);
      p.fill(204, 101, 192, 127);
      x = x+1
      y = y+1
      p.testFunction()
      } 
    };
    */


  checkBackendStatus(){
    console.log("checkingStatus");
    
    fetch("/getBackendStatusAPI")
      .then(res =>res.json())
      .then(res => {this.updateBackendStatusState(res)})
      .catch(err => err)
   
  }


  getNextBatchOfMovment(){
    console.log("Getting batch movment")
    fetch("/testDataAPI")
      .then(res =>JSON.parse(res))
      .then(res => {this.updateBackendStatusState(res)})
      .catch(err => err)
  }

  updatemoment(jsonMovment){
    this.movment = jsonMovment
  }

  updateBackendStatusState(StatusJson)
  {
    
    console.log("updatingStatus");
    console.log(StatusJson)
    if(StatusJson === undefined){
      console.log("UndefinedStatus");
      this.setState({NodeServerStatus:false});
      


    }else{
      //var keys = Object.keys(StatusJson);
      if("nodeServer" in StatusJson){
        
        var Bufferstatus = StatusJson["nodeServer"]

        this.setState({NodeServerStatus: Bufferstatus});
        console.log("found and set node status"+this.state.NodeServerStatus)
      
      }
    }
    this.render()
  }
  

  callDataAPI(){
    fetch("/testDataAPI")
      .then(res => res.text())
      .then(res => this.setState({apiResponse : res}))
      .catch(err => err)
  } 

  componentDidMount(){
    console.log("mounting")
    this.callDataAPI()
    this.checkBackendStatus()
    this.getNextBatchOfMovment()
  }

  
  render() {
    
    let Nodetext;
    console.log("this is the status"+this.state.NodeServerStatus )
    if(this.state.NodeServerStatus === true){
      Nodetext = "Node server online"
    }else{
      Nodetext = "Node server offline"
    }
    
    return (
      


      <div className="App">
        
          
          <DataWindow/>
        
        
      </div>

      
    );
  }
}


export default App;
