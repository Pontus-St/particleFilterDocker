import React, { Component } from "react";
import Sketch from "react-p5";
import { func } from "prop-types";
import Button from '@material-ui/core/Button';
import AppBar from '@material-ui/core/AppBar';
import { Toolbar, Container } from "@material-ui/core";
import Slider from '@material-ui/core/Slider';
import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import { get } from "https";

class people {
    constructor(parent) {
      
      this.diameter = 10;
      this.speed = 1;
      this.pos =  [];
      this.posHistory = []
      this.infectionHistory = []
      this.guessHistory = []
      this.landmarks=[]
      this.addpeople(this);
      this.gameId = undefined
      this.parent =parent 
      
    }
  
    addpeople(self,numberOFPeople){
        
        for (let i = 0; i < 10; i++) {
            let x = 100*(Math.random())
            let y = 100*Math.random()
            self.pos.push([x,y])
          }
    }
    move() {
        for (let i = 0; i < 10; i++) {
            this.pos[i][0] += (Math.random()-0.5)*10
            this.pos[i][1] += (Math.random()-0.5)*10
        }
      
    }
      
    getNewGameRequest(numberOFPeople){
        this.posHistory = []
        this.infectionHistory = []
        this.guessHistory = []
        this.landmarks=[]
        console.log("getting new game from server")
        fetch("/getNewWorld/"+numberOFPeople)
        .then(res => res.text())
        .then(res => {this.setNewGame(res)})
        .catch(err => err)
        
    }
    setNewGame(gameId){
        console.log("Got new game " + gameId)
        
        this.gameId = gameId
        this.parent.setState({nextTurnDisabled : false})
    }

    getPositionsFromServer(){
        console.log("getting postion from server")
        let requestText = "/getNextTurn/" + this.gameId
        console.log("getting postion from server " +  requestText)
        fetch(requestText)
        .then(res => res.json())
        .then(res => {this.updatePosHistory(res)})
        .catch(err => err)
        

    }
  
    updatePosHistory(data){
        console.log("updatePosHistory was called" + data.PersonPosData[2])
        
        var b = data.PersonPosData.split(',').map(Number);
        let startIdx =parseInt(b[0])
        let stopIdx =parseInt(b[1])
        console.log(this.posHistory.length )
        console.log(parseInt(startIdx)+" " + stopIdx)
        if(this.posHistory.length === startIdx) {
            console.log("updatePosHistory was called, correct idx")
            for(let i = startIdx; i<stopIdx;i++ ){
                //console.log(i)
                //console.log(data[i])
                var xy = data[i].split("],")
                var x = xy[0].replace(/[[\]]/g,"").trim().split(',').map(Number);
                var y = xy[1].replace(/[[\]]/g,"").trim().split(',').map(Number);
                //console.log("len x "+ x.length)
                //console.log("len y "+ y.length)
                this.posHistory.push([x,y])


                var keytext = "infected-" +i 
                var infected = data[keytext]
                //var infected = infected.split();
                //console.log("INFECTED :" +  infected)
                this.infectionHistory.push(infected)
                
                
            }
            console.log(this.infectionHistory.length +" " + this.posHistory.length)
            this.parent.startDrawing()
            this.parent.setState({nextTurnDisabled : false})
        }else{
            console.log(this.posHistory[0][0][0])
            
            console.log(this.posHistory[0][0][0] -0.5 )
            
        }
    }

    agetGuessFromServer(id,turn){
        if(id == this.gameId){
            let requestText = "/getPosForTurn/" + id + '/'+turn
            console.log("getting guess from server " +  requestText)
            fetch(requestText)
            .then(res => JSON.parse(res))
            .then(res => {this.updateGuessHistory(turn,res)})
            .catch(err => err)
        }
    }
    updateGuessHistory(turn,data)
    {
        console.log("updated guess"+data.length + "  " +data[0].length )
        this.guessHistory.push(data);
    }
  }


export default class App extends Component {

  historyIDX = 0
  peopleHandler = new people(this)
  canvas
  
  P5 = undefined
  prev = 0
  xOffset = 270 
  constructor(props) {
    super(props);
    // Don't call this.setState() here!
    this.state = { nextTurnDisabled: true , turnNumber : 0,turnsWithoutGuesses:[], numberOfDots : 1,numberOfDotsSliderValue : 1, busyGettingGuesses : false};
    
  }

  setup = (p5, canvasParentRef) => {
    this.canvas = p5.createCanvas((window.innerWidth -50), (window.innerHeight-50));
    p5.frameRate(45)
    this.P5 = p5
  };
  draw = p5 => {
    p5.background(255);
    if (this.peopleHandler.posHistory.length > 1){
        //console.log(this.historyIDX)
        if (this.historyIDX >= this.peopleHandler.posHistory.length-1){
            //this.historyIDX = 0
            p5.noLoop();
            this.drawGuessPostions(p5)
            this.drawGroundTruth(p5)
            this.drawLandmarks(p5)
            
            let infoText = this.peopleHandler.gameId +"-" + this.prev
            p5.text(infoText,100,100)
        }else{
            
            this.drawGuessPostions(p5)
            this.drawGroundTruth(p5)
            this.drawLandmarks(p5)
            if(this.historyIDX%10 === 0 ){
                this.prev = this.historyIDX
            
            }
            let infoText = this.peopleHandler.gameId +"-" + this.prev
            p5.text(infoText,100,100)
            this.historyIDX +=1
        }
        let infoText = this.peopleHandler.gameId +"-" + this.prev
        p5.text(infoText,100,100)
    }else{
        p5.text("no data", 100,100)
    }
    
    
    // NOTE: Do not use setState in draw function or in functions that is executed in draw function... pls use normal variables or class properties for this purposes
    this.x++;
  };

  drawLandmarks(p5){
    
    if(this.peopleHandler.landmarks.length > 0){
    
      for(let i = 0; i < this.peopleHandler.landmarks.length; i ++){
        let x = this.peopleHandler.landmarks[i][0]
        let y = this.peopleHandler.landmarks[i][1]
        x = Math.round((x/200)*(window.innerWidth-100))+this.xOffset
        y = 50+Math.round(((100-y)/100)*(window.innerHeight-150))
        //console.log("drawing landmarks"+x+" "+y)
        p5.fill(60, 168, 50, 127);
        p5.rect(x,y, 15, 15);
      }
    }
  }

  drawGroundTruth(p5){
    
    for (let i = 0; i <this.peopleHandler.posHistory[this.historyIDX][0].length; i++) {
        
        let x = this.peopleHandler.posHistory[this.historyIDX][0][i]
        let y = this.peopleHandler.posHistory[this.historyIDX][1][i]
        x = Math.round((x/200)*(window.innerWidth-100))+this.xOffset
        y = 50+Math.round(((100-y)/100)*(window.innerHeight-150))
        //console.log("pos: "+x+" "+y)
        if(this.peopleHandler.infectionHistory[this.historyIDX][i] === 1){
            p5.fill(204, 101, 192, 127);
        }else{
            p5.fill(255, 255, 255, 127);
        }
        p5.ellipse(x,y, 10, 10);
        
        
    }
  }
  drawGuessPostions(p5){
    // check if any data available
    if(this.peopleHandler.guessHistory.length >0){    
        let stepsPerTurn = this.peopleHandler.guessHistory[0][0].pos.length
        let currentturn = Math.floor( this.historyIDX/stepsPerTurn)
        //check if data available
        if(currentturn < this.peopleHandler.guessHistory.length){
            let currentTimeStepInTurn = this.historyIDX%stepsPerTurn
            
            

            //for each particle
            for (let i = 0; i <this.peopleHandler.guessHistory[currentturn].length; i++) {
                
                let data = this.peopleHandler.guessHistory[currentturn][i].pos[currentTimeStepInTurn]
                
                
                
                //let y = this.peopleHandler.posHistory[currentturn][1][i]


                let x = Math.round((data[0]/200)*(window.innerWidth-100))+this.xOffset
                let y = 50+Math.round(((100-data[1])/100)*(window.innerHeight-150))
                let a = Math.round((data[2]/200)*(window.innerWidth-100))
                let b = Math.round((data[3]/200)*(window.innerWidth-100))
                //if(this.peopleHandler.infectionHistory[this.historyIDX][i] === 1){
                //  p5.fill(204, 101, 192, 127);
                //}else{
                //console.log(x+" "+y)

                p5.fill(216, 235, 52, 127);
                //}
                p5.push()
                p5.translate(x,y)
                p5.angleMode("DEGREES");
                p5.rotate(data[4])
                p5.ellipse(0,0,Math.max( data[3],10),Math.max( data[2],10));
                
                p5.pop()
                //p5.rotate(0)
                
                
            }
        }
    }
  }

  handleClick = p5=> {
    //this.peopleHandler.getPositionsFromServer();
    //this.peopleHandler.move();
    p5.loop()
  }

    getGameId(){
      
    return this.peopleHandler.gameId
      

    }
    getNewGameRequestButton(){
        this.setState({nextTurnDisabled : true,turnNumber:0, turnsWithoutGuesses:[], busyGettingGuesses : 0})
        this.peopleHandler.getNewGameRequest(this.state.numberOfDotsSliderValue);
        this.historyIDX = 0
        this.P5.loop()
    }
    getNextTurn(){
        
        this.getLandmarks(this.peopleHandler.gameId)
        
        this.P5.loop();
        this.peopleHandler.getPositionsFromServer();
        this.state.turnsWithoutGuesses.push(this.state.turnNumber);
        if(this.state.busyGettingGuesses === 0){
            this.GetGuess(this.state.turnNumber, this.peopleHandler.gameId);
        }
        
        
        this.setState({nextTurnDisabled : true, turnNumber: this.state.turnNumber+1 })
        console.log("turn guess to get"+this.state.turnsWithoutGuesses)
    }
    
    startDrawing(){
        this.P5.loop()
    }

    replayAllTurns(){
        this.historyIDX = 0
        this.P5.loop()
    }

    GetGuess(turn,id){
        console.log("guesses left to get: "+ this.state.turnsWithoutGuesses)
        if(id === this.peopleHandler.gameId){
            this.setState({busyGettingGuesses : 1})
            let requestText = "/getPosForTurn/" + id + '/'+turn
            console.log("getting guess from server " +  requestText)
            fetch(requestText)
            .then(res => res.json())
            .then(res => {console.log("rescived");this.checkIfPosGussOK(turn,id,res)})
            .catch(err => err)
        }else{
            this.setState({busyGettingGuesses : 0})
        }
    }
    getLandmarks(id){
        let requestText = "/getLandmarkPos/" + id 
            console.log("getting guess from server " +  requestText)
            fetch(requestText)
            .then(res => res.json())
            .then(res => {console.log("rescived");this.checkIfLandmarkOK(res,id)})
            .catch(err => err)
    }

    checkIfLandmarkOK(data,id){
        console.log("recived landmarks:"+data)
        if(data == false){
            console.log("no data available, checking again in a while")
            const timer = setTimeout(() => {
                this.getLandmarks(id)
              }, 3000);
            return () => clearTimeout(timer);
            
        }else{
            
            for(let i = 0; i < data.length;i++){
               
                this.peopleHandler.landmarks.push([data[i].x,data[i].y])
                
            }
        }
    }

    checkIfPosGussOK(turn,id,data){
        console.log("recived:"+data)
        let checkAgain = false
        if(data == false){
            if(id == this.peopleHandler.gameId){

           
            console.log("no data available, checking again in a while")
            checkAgain = true
            }
            
        }else{
            console.log("got Data")
            this.peopleHandler.updateGuessHistory(turn,data)
            let arr = this.state.turnsWithoutGuesses
            arr.shift()
            this.setState({turnsWithoutGuesses : arr});
            if(this.state.turnsWithoutGuesses.length >0){
                
                checkAgain = true
                
            }else{
                this.setState({busyGettingGuesses : 0})
            }
            
        }
        if(checkAgain){
            const timer = setTimeout(() => {
                this.GetGuess(this.state.turnsWithoutGuesses[0],id)
            }, 3000);
            return () => clearTimeout(timer);
        }
    }

  render() {
      //<Sketch setup={this.setup} draw={this.draw} mouseClicked = {this.handleClick.bind(this)} />
    return (
    <div>
        
            <Drawer
                
                variant="permanent"
                
                anchor="left"
            >
            
            <Toolbar >
                <List>
                <ListItem>
                    <Button edge = "start" onClick={this.getNewGameRequestButton.bind(this)} >
                        new Game
                    </Button>
                </ListItem>
                <ListItem>
                    <Button edge = "start" disabled = {this.state.nextTurnDisabled} onClick={this.getNextTurn.bind(this)} >
                        Next turn
                    </Button>
                </ListItem>
                <ListItem>
                    <Button edge = "start" onClick={this.replayAllTurns.bind(this)} >
                        Replay
                    </Button>   
                
                </ListItem>
                <ListItem>
                    <text> Ground truth loaded: {this.state.turnNumber}</text>
                </ListItem>
                <ListItem>
                    <text> Guess loaded: {this.peopleHandler.guessHistory.length}</text>
                </ListItem>
                <ListItem>
                    <text> getting :{this.state.busyGettingGuesses} </text>
                </ListItem>
            
                <text >number of dots: { this.state.numberOfDotsSliderValue}</text>
                <Slider
                    defaultValue={3}
                    step={5}
                    marks
                    min={1}
                    max={100}
                    valueLabelDisplay="auto"
                    onChange={ (e, val) => this.setState({numberOfDotsSliderValue : val})}
                />
                </List>
            </Toolbar>
                
               
           
        
           
        </Drawer>
        
                
            <Container>
            <Sketch setup={this.setup} draw={this.draw}  />
            </Container>
    </div>
           )
  }
}

