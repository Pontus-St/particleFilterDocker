# -*- coding: utf-8 -*-
"""
@author: Pontus
"""
import numpy as np
import matplotlib.pyplot as plt
import sklearn.neighbors
import json
class worldManager:

    def __init__(self,numberOfPeople = 100):
        self.minX = 0 
        self.minY = 0
        self.maxX = 100
        self.maxY = 100
        
        self.time = 0
        
        self.people = []
        self.landmarks = []

        self.history = []
        self.infectionHistory = []
        minPos = np.array([self.minX,self.minY])
        maxPos = np.array([self.maxX,self.maxY])
        print(minPos,maxPos)
        for i in range(numberOfPeople):
            pos = np.random.uniform(minPos,maxPos)
            p = worldManager.person(pos,self)
            #print(pos)
            self.people.append(p)
        
        for i in range(3):
            pos = np.random.uniform(minPos,maxPos)
            #print(pos)
            l = worldManager.Landmark(pos)
            self.landmarks.append(l)
        self.history.append(self.getPeoplePosition())
        self.people[0].infected = True
        self.getInfected()
    def batchUpdate(self,times):
        self.peopleObservations =[]
        for i in range(times):
            self.update()

        

    def getInfected(self):
        infectedBuffer = []
        for p in self.people:
            if p.infected:
                infectedBuffer.append(1)
            else:
                infectedBuffer.append(0)
        self.infectionHistory.append(infectedBuffer)
    def update(self):
        
        for p in self.people:
            p.update()
            
        self.time += 1
        self.setInfected()
        self.getInfected()
        self.history.append(self.getPeoplePosition())
        

    def move(self,currentPos, delta):
        
        newPos = currentPos + delta
        compare = currentPos + delta
        bumped = False
        newPos[0] = max(newPos[0],self.minX)
        newPos[0] = min(newPos[0],self.maxX)
        
        newPos[1] = max(newPos[1],self.minY)
        newPos[1] = min(newPos[1],self.maxY)
        if not np.array_equal( newPos , compare):
            bumped = True
        return newPos, bumped

    def getWalls(self):
        walls = [self.minX,self.maxX,self.minY,self.maxY]
        return walls
    #debug
    def draw(self):
        x = np.zeros(len(self.people))
        y = np.zeros(len(self.people))
        i = 0
        peopleColor = []
        for p in self.people:
            x[i] = p.pos[0]
            y[i] = p.pos[1]
            if p.infected:
                peopleColor.append('r')
            else:
                peopleColor.append('k')
            i += 1
        peopleColor 
        plt.scatter(x,y,c = peopleColor )

        xl = np.zeros(len(self.landmarks))
        yl = np.zeros(len(self.landmarks))
        i = 0
        for l in self.landmarks:
            xl[i] = l.pos[0]
            yl[i] = l.pos[1]
            i += 1
        plt.scatter(xl,yl,c = 'b')


        plt.axis(xlim=(self.minX,  self.maxX), ylim=(self.minY,  self.maxY))
        
        
        plt.show()

    def setInfected(self):
        radiusForInfection = 5
        X = np.zeros((len(self.people),2))
   
        i = 0
        infected = []
        for p in self.people:
            X[i,0] = p.pos[0]
            X[i,1] = p.pos[1]
            
            if p.infected:
                infected.append(i)

            i += 1

        #print(sklearn.__version__)
        tree = sklearn.neighbors.KDTree(X, leaf_size=2) 
        for i in infected:
            neighbours= tree.query_radius( X[i,:].reshape(1, -1) , r=radiusForInfection)
            #print("neigh",neighbours)
            for n in neighbours[0]:
                #print(n)
                self.people[int(n)].infected = True
        #print(tree.query_radius( X, r=5, count_only = True))
    def getPeoplePosition(self):
        positions = np.zeros((len(self.people),2))

        for ind,p in enumerate(self.people):
            positions[ind,0] = p.pos[0]
            positions[ind,1] = p.pos[1]
        positions = np.transpose(positions)
        #print(positions)
        return np.array2string( positions, precision=2, separator=',',suppress_small=True)

    def getPersonPositionJson(self,intStart, intEnd):
        BufferDict = {"PersonPosData" : "{},{}".format(intStart,intEnd)}
        for i in range(intStart,intEnd):
            BufferDict.update({i:self.history[i]})
            buffer = "infected-" + str(i)
            BufferDict.update({buffer:self.infectionHistory[i]})
        BufferDict = json.dumps(BufferDict)
        
        return BufferDict
    def getLenghtOfHistory(self):
        return len(self.history)

    
    def getObservations(self,intStart, intEnd):
        data = []
        counter = 0
        for p in self.people:
            idnumber = p.id
            info =p.observations[intStart:intEnd]
            data.append([counter, info])
            counter+=1
            
        return data
    def getLandMarks(self):
        landmarkList =[]
        for i in self.landmarks:
            Buffer = [i.id, list(i.pos)]
            landmarkList.append(Buffer)
        return landmarkList
    class person:
        idRunning = 0
        def __init__(self,pos,WM):
            self.pos = pos
            self.id = worldManager.person.idRunning
            worldManager.person.idRunning += 1 
            self.WM =  WM
            self.oldDelta = np.zeros(2)
            self.maxDelta = 0.6
            self.infected = False
            self.observations = []
        def update(self):
            self.move()
            return self.recordData()

        def recordData(self):
            data = []
            for l in self.WM.landmarks:
                signal = l.getSignalstrenght(self.pos)
                buffer = signal
                data.append(buffer)
            #print(data)
            self.observations.append(data)
            #print(len(self.observations))
            
        
        def move(self):
            delta = self.oldDelta + np.random.normal(0,0.05,2)
            #delta = delta + 1
            self.oldDelta = delta

            if np.linalg.norm(delta) > self.maxDelta:
                #print("maxad")
                delta = self.maxDelta*(delta/np.linalg.norm(delta))

            self.pos, bumped = self.WM.move(self.pos, delta)
            if bumped:
                #print("bumped")
                self.oldDelta = np.zeros(2)

    class Landmark:
        idRunning = 0
        def __init__(self,pos):
            self.pos = pos

            self.id = worldManager.Landmark.idRunning
            worldManager.Landmark.idRunning += 1 

            self.range = 200

        def getSignalstrenght(self,atPos):
            distance = np.linalg.norm(self.pos-atPos)
            return distance
            
        def signalFunction(self,distance):
            #return max(0,self.range*np.exp(-distance/self.range)+np.random.normal(0,10))     
            return max(0,distance+np.random.normal(0,10))

if __name__ == "__main__" :
    Wm = worldManager()
    for i in range(100):
        Wm.update()
        Wm.draw()
        c = 0
        #print(len(Wm.history)," ",len(Wm.infectionHistory))
