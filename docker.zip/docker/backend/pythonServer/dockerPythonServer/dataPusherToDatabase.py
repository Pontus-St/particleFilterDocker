import psycopg2
import json

def createNewGameSchema(gameId,curr,conn):
    cmdDrop = """
    DROP SCHEMA  IF EXISTS  game{} CASCADE;
    """.format(gameId)

    cmdCreate = """
        CREATE SCHEMA IF NOT EXISTS game{}
    """.format(gameId)

    curr.execute(cmdDrop)
    conn.commit()
    curr.execute(cmdCreate)
    conn.commit()

def createNewtable(gameId,turn,curr,conn):

    cmd = """
        CREATE TABLE game{}.turn{} (
            id integer Not null,
            observations real[][] NOT NULL
        )
    """.format(gameId,turn)
    curr.execute(cmd)
    conn.commit()

def addPointToTable(gameId,turn,curr,conn,idnumber,observationlist):
    cmd = """INSERT INTO game{}.turn{} (id,observations)
             VALUES(%s,%s) """.format(gameId,turn)
    curr.execute(cmd,(idnumber,observationlist))
    conn.commit()

def addLandmark(gameId,curr,conn,landmarks):
    cmd = """
       CREATE TABLE IF NOT EXISTS game{}.landmarks (
            id int not null,
            x real NOT NULL,
            y real NOT NULL
        )
    """.format(gameId)
    curr.execute(cmd)
    conn.commit()
    for i in landmarks:
        idnumber = i[0]
        x = i[1][0]
        y = i[1][1]
        cmd = """INSERT INTO  game{}.landmarks (id,x,y)
                VALUES(%s,%s,%s) """.format(gameId)
        curr.execute(cmd,(idnumber,x,y))
    conn.commit()

def createConnection():
    conn = psycopg2.connect(host="pg-docker", user="postgres", password="docker")
    cur = conn.cursor()
    return cur, conn

def closeConnection(conn):
    conn.close()
'''
def pushData(observations,landmarks,gameid, turn):
    cur, conn = createConnection()
    if turn == 0:
        createNewGameSchema(gameid,cur,conn)
    createNewtable(gameid,turn,cur,conn)

    data = json.loads(jsonData)
    print(data.keys)
    particles = []
    for i in data:
        if not("PersonPosData" in i or "infected" in i):
            particles.append(i)

    for i in particles:
        buffer = data["{}".format(i)]
        #print(buffer)
        buffer = buffer.replace("\n","")
        buffer = buffer.split("], [")
        buffer[0] = buffer[0].replace("[","")
        buffer[1] = buffer[1].replace("]","")
        #print("b",len(buffer),buffer)
        x = [float(s) for s in buffer[0].split(",")]
        y = [float(s) for s in buffer[1].split(",")]
        #print(len(x)," ",len(y))
        
        addPointToTable(gameid,turn,cur,conn,x,y)
        
    closeConnection(conn)
    print("done pushing to DB")
    
    
        
'''
def pushData(observations,landmarks,gameid, turn):
    cur, conn = createConnection()
    
    #create schema 
    if turn == 0:
        createNewGameSchema(gameid,cur,conn)
            #create landmark list
        addLandmark(gameid,cur,conn,landmarks)
    
    createNewtable(gameid,turn,cur,conn)


    
    for i in observations:
        addPointToTable(gameid,turn,cur,conn,i[0],i[1])
        
    closeConnection(conn)
    print("done pushing to DB")

def resetDatabase():
    print("resetting database...")
    cur, conn = createConnection()
    cur.execute("""select schema_name
    from information_schema.schemata;""")
    for table in cur.fetchall():
        t = table[0]
        #print(t)
        if "game" in t:
            print("dropping:",t)
            cur.execute("""DROP SCHEMA IF EXISTS {} CASCADE ; """.format(t))
            conn.commit()
    closeConnection(conn)
    print("done")
        

if __name__ == "__main__":
    resetDatabase()
    '''
    cur, conn = createConnection()
    createNewGameSchema(0,cur,conn)
    createNewGameSchema(1,cur,conn)
    createNewtable(0,0,cur,conn)
    createNewtable(1,0,cur,conn)
    createNewtable(0,1,cur,conn)
    createNewtable(1,1,cur,conn)
    #addPointToTable(0,0,0,cur,conn,1,2)
    cur.execute("""select schema_name
    from information_schema.schemata;""")
    for table in cur.fetchall():
        print(table)

    
    cur.execute("""select * from game0.turn0""")
    for table in cur.fetchall():
        print(table)
    closeConnection(conn)
    '''