#
#   Hello World server in Python
#   Binds REP socket to tcp://*:5555
#   Expects b"Hello" from client, replies with b"World"
#

import time
import zmq

import SimpleBox
import json
import dataPusherToDatabase as D2D
import time

time.sleep(3)

context = zmq.Context()
socket = context.socket(zmq.REP)
socket.bind("tcp://*:9998")
WM = SimpleBox.worldManager()
Worlds = {}
D2D.resetDatabase()
while True:
    print("waiting")
    message = str(socket.recv())
    print("Received request: %s" % message)
    message= message[2:-1]
    unalteredMessage = message.split("-")
     
    idNumber =-1
    if len(message) >1 :
        idNumber = unalteredMessage[1]
        message = unalteredMessage[0] 
    
    print("splint into:","|" , idNumber,"|" , message ,"|" ,)
    if message == "new":
        print("new world created for ", idNumber, unalteredMessage[-1] )
        bufferWM = SimpleBox.worldManager(int(unalteredMessage[-1] ))
        Worlds.update({idNumber:bufferWM})
        socket.send_string(idNumber)
   
    elif message == b"Walls":
        print("sent walls")
        socket.send_json(WM.getWalls())

    elif message =="next":

        if idNumber in Worlds:
            
            print("generating next turn for ", idNumber)
            framesToSend = 100
            wm = Worlds.get(idNumber)
            wm.batchUpdate(framesToSend)
            startIdx = wm.getLenghtOfHistory() - framesToSend -1
            toSend =wm.getPersonPositionJson(startIdx,startIdx+framesToSend)
            landmarks = wm.getLandMarks()
            observations = wm.getObservations(startIdx,startIdx+framesToSend)
            #print(observations[0])
            D2D.pushData(observations,landmarks,idNumber, int(startIdx/100))
            
            print("sending")
            socket.send_string(toSend)
            #wm.draw()
        else:
            socket.send_string("Key not in world dictionary")

    elif message == b"ping":
        socket.send(b"pong")   

    else:
        socket.send(b"not an option")
    
    #  Send reply back to client
    