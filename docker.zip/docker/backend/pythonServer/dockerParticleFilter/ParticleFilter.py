# -*- coding: utf-8 -*-
"""
@author: Pontus
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal
from numpy import linalg as LA
#one per person


class ParticleFilter:
    c_gauss = 1/(np.sqrt(2*np.pi)) 
    def __init__(self,landmarks, maxX=100,minX=0,maxY=100,minY=0):
        #world limits
        self.debug = False
        self.maxX = maxX
        self.minX = minX
        self.maxY = maxY
        self.minY = minY
        self.landmarks =landmarks

        self.numOfParticles = 30
        self.particles = None
        self.weights =None
        self.resetParticles()

        self.mean = None
        self.covar = None
        self.timeStep = 0
        self.fitGaussian()
  
        
    def resetParticles(self):
        minPos = np.array([self.minX,self.minY])
        maxPos = np.array([self.maxX,self.maxY])

        self.particles = np.random.uniform(minPos,maxPos,(self.numOfParticles,2))
        self.weights = np.ones(self.numOfParticles)/self.numOfParticles

    def getProbabilityOfObservation(self,observations,pos):

        prob = 1 
        guess_Var = 2

        for i in range(len(observations)):
            #translate observation to mean:
            mean = observations[i]
            #current pos is the x i want probability for, need to translate pos to observation relavant distance 
            landmarkPos = np.array(self.landmarks[i])
            x = np.linalg.norm(landmarkPos - pos) #distance
             
            buffer = self.gaussianPDF(x,mean,guess_Var)

            prob *= buffer
            #print(prob)
        
        return prob


    def gaussianPDF(self,x,mean,var):
        c = (1/var)*ParticleFilter.c_gauss
        exponent = -0.5*np.power((x-mean)/2,2)
        return c*np.exp(exponent)


    def getNewPoint(self,oldPointIndex):
        oldPos = self.particles[oldPointIndex,:]
        delta = np.random.normal(0,5,2)
        
        newPos = oldPos + delta
        
        newPos[0] = max(newPos[0],self.minX)
        newPos[0] = min(newPos[0],self.maxX)
        
        newPos[1] = max(newPos[1],self.minY)
        newPos[1] = min(newPos[1],self.maxY)
    
        return newPos
    def update(self,observations):

        #sample new points around old points dependent on old weights
        index = np.arange(0,self.numOfParticles)
        selected = np.random.choice(index,size =self.numOfParticles, replace = True, p = self.weights)
        #print(selected)

        newPoints = np.zeros((self.numOfParticles,2))
        weightSum = 0
        for i,ind in enumerate(selected):
            newPoints[i,:] = self.getNewPoint(ind)
            #calc weight for new points 
            self.weights[i] = self.getProbabilityOfObservation(observations, newPoints[i,:])
            weightSum += self.weights[i]
        self.particles = newPoints
        #normalize
        for i in range(len(self.weights)):
            self.weights[i] = self.weights[i] / weightSum 
        #print(self.weights)
    def draw(self):
        size = self.weights*100
        plt.scatter(self.particles[:,0],self.particles[:,1],s = size)

        plt.axis([self.minX,self.maxX,self.minY,self.maxY])
        plt.show()

    def fitGaussian(self):
        meanX = self.weights * self.particles[:,0]
        meanX = np.sum(meanX)/np.sum(self.weights)

        meanY = self.weights * self.particles[:,1] 
        meanY = np.sum(meanY)/np.sum(self.weights)

        self.mean = np.array([[meanX],[meanY]])
        X = np.transpose(self.particles)
        X = X - self.mean
        
        self.covar= np.dot(self.weights*X,np.transpose(X))/np.sum(self.weights)
        
        #print(self.covar)
        if self.debug:
            try:
                rv = multivariate_normal(np.squeeze(self.mean), self.covar)
                
                fig2 = plt.figure()
                ax2 = fig2.add_subplot(111)
                x, y = np.mgrid[0:100:1, 0:100:1]
                pos = np.dstack((x, y))
                ax2.contourf(x, y, rv.pdf(pos))
                plt.show()
            except:
                pass
    def getPlottingParam(self):
        x = self.mean[0][0]
        y = self.mean[1][0]
        #95% border
        c = np.sqrt(5.991)
        
        covx = self.covar[0,0]
        covy = self.covar[1,1]
        lenghtx = 2*covx*c
        lenghty = 2*covy*c
        if np.isnan(self.covar).any() or np.isinf(self.covar).any():
            self.resetParticles()
            return [1,1,1,1,1]
        w, v = LA.eig(self.covar)
        #print("W: ", w, " v ",v)
        eigv = v[:,0]
        if(w[0]<w[1]):
            eigv = v[:,1]
        
        a = np.arctan2(eigv[0],eigv[1])
        if(lenghtx<lenghty):
            a = a +90
        
        #print("a", np.rad2deg(a ))
        self.timeStep +=1 
        return [np.round(x,2),np.round(y,2),np.round(lenghtx,2),np.round(lenghty,2),np.round(a,2)]
        
if __name__ == "__main__" :
    PF = ParticleFilter(100,0,100,0)
    obsPos1 = np.array([0,100])
    obsPos2 = np.array([100,0])
    PF.debug = True
    for i in range(100):
        obs1 = [i,obsPos1]
        obs2 = [100-i,obsPos2]
        observations = [obs1,obs2]
        PF.fitGaussian()
        print(PF.getPlottingParam())
        #PF.draw()
        PF.update(observations)
        print(i)
        