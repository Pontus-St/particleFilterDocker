import psycopg2
import ParticleFilter 
import time
import os

PFMap = {}

def createNewGuessSchema(gameId,curr,conn):
    cmdDrop = """
    DROP SCHEMA  IF EXISTS  game{} CASCADE;
    """.format(gameId)

    cmdCreate = """
        CREATE SCHEMA IF NOT EXISTS game{}
    """.format(gameId)

    curr.execute(cmdDrop)
    conn.commit()
    curr.execute(cmdCreate)
    conn.commit()

def createNewtable(gameId,turn,curr,conn):

    cmd = """
        CREATE TABLE game{}.turn{} (
            particle_id SERIAL PRIMARY KEY,
            x NUMERIC (3, 2) NOT NULL,
            y NUMERIC (3, 2) NOT NULL
        )
    """.format(gameId,turn)
    curr.execute(cmd)
    conn.commit()

def addPointToTable(gameId,turn,curr,conn,x,y):
    cmd = """INSERT INTO game{}.turn{} (x,y)
             VALUES(%s,%s) """.format(gameId,turn)
    curr.execute(cmd,(x,y))
    conn.commit()

def createConnection():
    
    conn = psycopg2.connect(host="pg-docker", user="postgres", password="docker")
    cur = conn.cursor()
    return cur, conn

def closeConnection(conn):
    conn.close()

def getAllAvailableGamesAndTables(cur,con):   
    cur.execute("""select schema_name
    from information_schema.schemata;""")
    schemas = []
    for schema in cur.fetchall():
        
        if "game" in schema[0]:
            schemas.append( schema[0])
            print( schema[0])
    for i in schemas:
        print(i)
        
        missing = checkIfSchemaHasPostionTable(cur,i)
        print("missing :",missing)
        gameid = int(i.replace("game",""))
        landmarks = getLandmarkInfo(gameid)
        #print(landmarks)
        updatePFOneTurn(gameid,missing,cur,con)


def checkIfSchemaHasPostionTable(cur,schema):
    cur.execute("""select t.table_name from information_schema.tables t
                    where t.table_schema = '{}' 
                    and t.table_type = 'BASE TABLE'
                    order by t.table_name;""".format(schema))
    turns = []
    guess = []
    for table in cur.fetchall():
        split = table[0].split("_")
        if  "landmarks" in table:
            pass
        elif len(split) <=1 :
            turns.append(split[0])
        else:
            guess.append(split[0])
    if len(turns) == len(guess):
        return []
    missingPos = []
    for i in turns:
        if not i in guess:
            missingPos.append(i)
    return missingPos
def getLandmarkInfo(GameID):
    cur.execute("""SELECT * from game{}.landmarks  """.format(GameID))
    buffer = []
    for table in cur.fetchall():
        buffer.append([table[1],table[2]])
    return buffer
        

def createParticlefilterForGame(GameID,particleId,landmarks):
    bufferPF = ParticleFilter.ParticleFilter(landmarks)
    idTag = (GameID, particleId)
    PFMap[idTag] = bufferPF


def updatePFOneTurn(GameID,missingTurns,cur,con):
    print("updating filters...")
    for t in missingTurns:
        print(t)

        

        cmd = """
        CREATE TABLE game{}.{}_pos (
            particle_id int not null,
            pos real[][] not null
        )
        """.format(GameID,t)
        cur.execute(cmd)
        con.commit()

        cur.execute("""SELECT * from game{}.{} """.format(GameID,t))
        for table in cur.fetchall():
            particleID = table[0]
            observation = table[1]
            
            #init filter
            if "turn0" in t:
                createParticlefilterForGame(GameID,particleID,getLandmarkInfo(GameID))
            buffer =[]
            #updatefilter
            for o in observation:
                idTag = (GameID, particleID)
                PFMap[idTag].update(o)
                PFMap[idTag].fitGaussian()
                buffer.append( PFMap[idTag].getPlottingParam())
            #print(buffer)
            cmd = """INSERT INTO game{}.{}_pos (particle_id,pos)
                    VALUES(%s,%s) """.format(GameID,t)
            cur.execute(cmd,(particleID,buffer))
            con.commit()
    print("Done updating")
    
if __name__ == "__main__":
    print("started")
    time.sleep(3)
    cur, conn = createConnection()
    print("connected")
    while True:
        
        getAllAvailableGamesAndTables(cur,conn)
        time.sleep(1)
    '''
    cur.execute("""SELECT * from game0.turn0 where id = 0 """)
    for table in cur.fetchall():
        pass
        #print(table)
    '''
    closeConnection(conn)