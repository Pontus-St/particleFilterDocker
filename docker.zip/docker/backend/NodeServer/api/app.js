var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var zmq = require("zeromq");
var socket = zmq.socket("req");
var counter = 0;
var data = "noResp";

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var testDataAPIRouter = require("./routes/testDataApi");
var getBackendStatusAPI = require("./routes/getBackendStatusAPI");
var getNextTurnRouter  = require("./routes/getNextTurn");
var getNewWorldRouter  = require("./routes/createNewEnviroment") ;
var getPosForTurnRouter = require("./routes/getPosForTurn");
var getLandmarkPosRouter = require("./routes/getLandmarks");

var cors = require("cors");
var pythonSimulation = require("./public/javascripts/simulation.js");
let pE = pythonSimulation.pE
var databaseRef = require("./public/javascripts/dataBase.js")
let db = databaseRef.db;
/*
function logToConsole (message) {
  console.log("[" + new Date().toLocaleTimeString() + "] " + message);
}
function sendMessage (message) {
  logToConsole("Sending: " + message);
  socket.send(message);
}

// Add a callback for the event that is invoked when we receive a message.
socket.on("message", function (message) {
  // Convert the message into a string and log to the console.
  logToConsole("Response: " + message.toString("utf8"));
  var debug = JSON.parse(JSON.parse(message.toString("utf8")));
  data =debug
  logToConsole(Object.keys(debug))
  exports.Data = JSON.stringify(data);
  
});

// Begin listening for connections on all IP addresses on port 9998.
socket.connect('tcp://localhost:9998');


socket.send("Buildings")
*/
var PE = new pE();
console.log(typeof(databaseRef))
var DB = new db();
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(cors());
app.options('*', cors());
app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use("/testDataAPI", testDataAPIRouter);
app.use("/getBackendStatusAPI",getBackendStatusAPI);
app.use("/getNextTurn",getNextTurnRouter);
app.use("/getNewWorld",getNewWorldRouter);
app.use("/getPosForTurn",getPosForTurnRouter)
app.use("/getLandmarkPos",getLandmarkPosRouter)
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

function getBuildingData(callback){
  return PE.getZoneData(callback);
}

function getNewWorld(NumberOfPersons,callback){
  return PE.createNewEnviroment(NumberOfPersons,callback);
}

function getNextTurnFunc(idNum,callback){
  return PE.getNextTurnData(idNum,callback);
}
function getPosForTurn(id,turn,callback){
  DB.checkAndGet(id,turn,callback)
}
function getLandmarks(turn,callback){
  DB.getLandmarks(turn,callback)
}

module.exports.PEData = getBuildingData;
module.exports.NewWorld = getNewWorld;
module.exports.getNextTurn = getNextTurnFunc;
module.exports.getPosForTurn = getPosForTurn;
module.exports.getLandmarks = getLandmarks;
module.exports = app;
