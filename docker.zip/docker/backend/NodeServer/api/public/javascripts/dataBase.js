const { Client } = require('pg');

class DatabaseHandler{
  constructor(){
    this.client= new Client({
      host: 'pg-docker',
      port: 5432,
      user: 'postgres',
      password: 'docker',});
    setTimeout(function(){this.client.connect(); console.log("connected")}.bind(this),3000)
    
    this.replyCallback = false
  }

  connect(){
    this.client.connect();
  }
  async checkIfTableExists(gameId,Turn){
    console.log("checking if table exist")
    
    let cmd = 'SELECT EXISTS (SELECT FROM information_schema.tables where table_schema = \'game'+gameId+'\' and table_name = \'turn'+Turn+'_pos\' )';
    let existsBool = await this.client.query(cmd)
    existsBool = existsBool.rows[0].exists
    console.log("checking if table exist:"+existsBool)
    
    return existsBool
  
  
  }
  async checkIfGameExists(gameId){
    console.log("checking if game exist")
    
    let cmd = 'SELECT EXISTS (SELECT FROM information_schema.tables where table_schema = \'game'+gameId+'\' and table_name = \'landmarks\' )';
    let existsBool = await this.client.query(cmd)
    existsBool = existsBool.rows[0].exists
    console.log("checking if table exist:"+existsBool)
    
    return existsBool
  
  
  }
  async sendQuery(gameId,turnId,callbackData){ 
    
    let data = await this.client.query('select * from game'+gameId+'.turn'+turnId+'_pos')
    let dataCheckRow = await this.client.query('select Count(*) from game'+gameId+'.turn'+turnId)
    console.log("numbers of rows:"+dataCheckRow.rows[0].count + " should be " + data.rowCount)
    if (data.rowCount ==dataCheckRow.rows[0].count){
      
      callbackData(JSON.stringify(data.rows))
    }else{
      callbackData(JSON.stringify(false))
    }
      
  }
  async sendLandmarkQuery(gameId,callbackData){ 
    
    let data = await this.client.query('select * from game'+gameId+'.landmarks')
    
      
    callbackData(JSON.stringify(data.rows))
    
      
  }
  async checkAndGet(gameId,turnId,callback){

    const tableExists = await this.checkIfTableExists(gameId,turnId);
    if(tableExists){
       console.log("data exists, asking for "+ gameId +" "+gameId )
       this.sendQuery(gameId,turnId,callback);
       

    }else{
      callback(JSON.stringify(false))
    }
  }
  RequestData(idnumber,turnnumber){
    let cmd = 'select * from game'+idnumber+'.turn'+turnnumber;
    this.client.query(cmd, (err, res) => {
      if(res.rowCount == 100){
        console.log(res.rows)
      }else{
        console.log("only partial results availble, discarding.")
      }
        
    })
  }

  getNextTurnData(idnumber,turnnumber, repcb){
    this.logToConsole("asked for position guess for" + idnumber + " " + turnnumber)

    if (this.replyCallback) {
        throw new Error('Cannot send request before receiving reply of preceding request!');
    }
    this.awaitingResponseType = 2
    this.replyCallback = repcb;
    let toSend = "next-"+  idnumber
    this.sendMessage(toSend);        
  }

  async getLandmarks(gameId,callback){
    const tableExists = await this.checkIfGameExists(gameId,0);
      if(tableExists){
          console.log("data exists, asking for landmarks for "+ gameId )
          this.sendLandmarkQuery(gameId,callback);
          

      }else{
        callback(JSON.stringify(false))
    }
  }
}
module.exports = {db:DatabaseHandler}
//let db = new DatabaseHandler()
//db.checkAndGet(0,0)
