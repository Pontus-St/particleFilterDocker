require("express")
var zmq = require("zeromq");


class pythonEnviromentConnection{

    constructor(){
        this.socket = zmq.socket("req");
        this.pythonServerAlive = false;
        this.pythonServerResponded = false;
        this.data = null ;
        this.replyCallback
        this.runningId = 0;
        this.awaitingResponseType = 0;
        // Add a callback for the event that is invoked when we receive a message.
        this.socket.on("message", function (message) {
            // Convert the message into a string and log to the console.
            //this.logToConsole("Response: " + message.toString("utf8"));
            if(message.toString("utf8") == "pong"){
                this.heartbeatDetected();
            }else{
                this.onRepHandler(message.toString("utf8"));
            }
            
            //exports.Data = JSON.stringify(data);
            this.data = message
        }.bind(this));
        setTimeout(function(){this.socket.connect('tcp://pythonserver:9998')}.bind(this),5000)
        //this.socket.connect('tcp://pythonserver:9998');
    }

    onRepHandler = function (reply) {
        let noJSon = reply
        //this.logToConsole(noJSon)
        if(this.awaitingResponseType == 1){
            //new world
            this.runningId +=1
            if (this.replyCallback) {
                this.replyCallback(noJSon);
            }
        }else if(this.awaitingResponseType == 2){
            //next turn
            if (this.replyCallback) {
                this.replyCallback(noJSon);
            }
            }
        
        else{
            //Coordinates 
            reply = JSON.parse(reply.trim())
            //this.logToConsole(JSON.stringify(reply))
            //this.logToConsole(reply["0"].trim())
            let a = reply["0"].trim()
            a = a.split("],")
            let a1 = a[0]
            a1 = a1.match(/\d+(?:\.\d+)?/g).map(Number)
            let a2 = a[1].match(/\d+(?:\.\d+)?/g).map(Number)
            //this.logToConsole(a1)
            if (this.replyCallback) {
                this.replyCallback(noJSon);
            }
        }
        this.replyCallback = undefined;

    }


    logToConsole (message) {
        console.log("[" + new Date().toLocaleTimeString() + "] " + message);
    }
    getNext(){
        this.logToConsole("asked for next from python")
        this.socket.send("next");
    }
    sendMessage (message) {
        this.logToConsole("Sending: " + message);
        this.socket.send(message);
    }
    heartbeatDetected(){
        this.pythonServerResponded = true
    }
    sendHeartbeat(){
        if(this.pythonServerResponded == false){
            this.pythonServerAlive = false
        }else{
            this.pythonServerAlive = true
        }

        this.socket.send("ping")
        this.pythonServerResponded = false
    }
    getData(){
        return this.data
    }
    getNextTurnData(idnumber, repcb){
        this.logToConsole("asked for next data" + idnumber)

        if (this.replyCallback) {
            throw new Error('Cannot send request before receiving reply of preceding request!');
        }
        this.awaitingResponseType = 2
        this.replyCallback = repcb;
        let toSend = "next-"+  idnumber
        this.sendMessage(toSend);        
    }
    createNewEnviroment(NumberOfPersons,repcb){
        this.logToConsole("asked for new enviroment"+ this.runningId+","+NumberOfPersons)

        if (this.replyCallback) {
            throw new Error('Cannot send request before receiving reply of preceding request!');
        }
        this.awaitingResponseType = 1
        this.replyCallback = repcb;
        let toSend = "new-"+  this.runningId+"-"+NumberOfPersons
        
        this.sendMessage(toSend);     
    }
    
}
module.exports = {pE:pythonEnviromentConnection}