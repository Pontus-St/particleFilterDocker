var express = require("express");
var router = express.Router();
var appjs = require('../app.js')

router.get("/:id/:turn", function(req, res, next) {
    console.log("asked for positions for " + req.params.id +' '+ req.params.turn)
    
    appjs.getPosForTurn(req.params.id, req.params.turn,function(response){
        res.send(response)
    });
    
    
});

module.exports = router;