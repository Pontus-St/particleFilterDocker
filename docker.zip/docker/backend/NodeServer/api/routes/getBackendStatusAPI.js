var express = require("express");
var router = express.Router();
var appjs = require('../app.js')

router.get("/", function(req, res, next) {

    var statusToReturn = {}
    statusToReturn["nodeServer"] =  true


    // transform to Json and send 
    statusToReturn = JSON.stringify(statusToReturn)
    res.send(statusToReturn);
});

module.exports = router;