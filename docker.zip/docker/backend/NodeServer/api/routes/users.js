var express = require('express');
var router = express.Router();
var appjs = require('../app.js')

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send("data:"+appjs.Data);
});

module.exports = router;
