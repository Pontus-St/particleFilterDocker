var express = require("express");
var router = express.Router();
var appjs = require('../app.js')

router.get("/", function(req, res, next) {
    
    appjs.PEData(function(response){
        res.send(response)
    });
    
});

module.exports = router;