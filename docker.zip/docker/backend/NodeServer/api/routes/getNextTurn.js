var express = require("express");
var router = express.Router();
var appjs = require('../app.js')

router.get("/:id", function(req, res, next) {
    console.log("asked for next " + req.params.id)
    
    appjs.getNextTurn(req.params.id,function(response){
        res.send(response)
    });
    
    
});

module.exports = router;