var express = require("express");
var router = express.Router();
var appjs = require('../app.js')

router.get("/:NumberOfPersons", function(req, res, next) {
    
    
    appjs.NewWorld(req.params.NumberOfPersons,function(response){
        
        res.send(response)
    });
    
    
});

module.exports = router;